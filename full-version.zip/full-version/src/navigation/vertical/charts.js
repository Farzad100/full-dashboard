export default [
  { heading: 'Charts' },
  {
    title: 'Charts',
    icon: { icon: 'tabler-chart-bar' },
    children: [
      { title: 'Apex Chart', to: 'charts-apex-chart' },
      { title: 'Chartjs', to: 'charts-chartjs' },
    ],
  },
]
